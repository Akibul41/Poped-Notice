
import { useEffect } from "react";

export default function NoticeModal({ onClose, children }) {
  useEffect(() => {
    const handleEsc = (e) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", handleEsc);
    return () => document.removeEventListener("keydown", handleEsc);
  }, [onClose]);

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6 relative animate-fade-in"
      >
        <button
          onClick={onClose}
          className="absolute top-2 right-2 bg-red-500 text-white w-10 h-10 rounded-full text-xl flex items-center justify-center hover:bg-red-600 transition"
        >
          &times;
        </button>
        <h2 className="text-xl font-bold mb-4 text-center">College Notices</h2>
        {children}
      </div>
    </div>
  );
}
