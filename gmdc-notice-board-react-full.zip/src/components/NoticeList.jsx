
export default function NoticeList({ notices }) {
  return (
    <div className="space-y-4 max-h-80 overflow-y-auto pr-2">
      {notices.map((notice, idx) => (
        <div
          key={idx}
          onClick={() => window.open(notice.link || "#", "_blank")}
          className="cursor-pointer p-4 border border-gray-300 rounded-lg hover:bg-blue-50 transition relative"
        >
          {notice.isNew && (
            <span className="absolute top-2 right-2 text-sm font-bold text-red-600 animate-pulse">
              NEW
            </span>
          )}
          <h3 className="font-semibold text-gray-800">{notice.title}</h3>
          <p className="text-sm text-gray-500">Date: {notice.date}</p>
        </div>
      ))}
    </div>
  );
}
