
export default function ErrorMessage({ message }) {
  return (
    <div className="p-4 text-red-600 bg-red-100 border border-red-300 rounded-lg">
      {message}
    </div>
  );
}
