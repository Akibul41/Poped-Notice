
import { useEffect, useState } from "react";
import NoticeModal from "./components/NoticeModal";
import NoticeList from "./components/NoticeList";
import SkeletonList from "./components/SkeletonList";
import ErrorMessage from "./components/ErrorMessage";

export default function App() {
  const [notices, setNotices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [modalOpen, setModalOpen] = useState(false);

  useEffect(() => {
    fetch("https://script.google.com/macros/s/AKfycbyLCPVWHxq-ZZLWYyAVKyvSRjxFogQJNt5KVKPd0J5klGAtVu5RdpYULfLhrzqbzDtMew/exec")
      .then((res) => res.json())
      .then((data) => {
        setNotices(data.notices);
      })
      .catch(() => {
        setError("Failed to load notices. Please try again later.");
      })
      .finally(() => setLoading(false));
  }, []);

  return (
    <main className="min-h-screen bg-gray-50 p-4 flex items-center justify-center">
      <button
        onClick={() => setModalOpen(true)}
        className="bg-blue-600 text-white px-6 py-3 rounded-lg shadow-lg hover:bg-blue-700 transition"
      >
        View Notices
      </button>

      {modalOpen && (
        <NoticeModal onClose={() => setModalOpen(false)}>
          {loading ? (
            <SkeletonList count={4} />
          ) : error ? (
            <ErrorMessage message={error} />
          ) : (
            <NoticeList notices={notices} />
          )}
        </NoticeModal>
      )}
    </main>
  );
}
